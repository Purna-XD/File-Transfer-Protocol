Compile:
javac Client.java
javac Server.java

Run:
java Client
java Server

Command Line:
Enter IP:191.191.191.191
Port: 9876(hard coded)
Enter bit error rate: 0 to 1
Enter your value from
list
get
exit

Ex: 
list+Enter
get test.txt+Enter
exit+Enter


