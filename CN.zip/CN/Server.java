import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.io.FileNotFoundException;

public class Server {

    // Maximum Segment Size - Quantity of data from the application layer in the segment
    public static final int MSS = 4;

    // Probability of loss during packet sending
    public static double PROBABILITY;

    // Window size - Number of packets sent without acking
    public static final int WINDOW_SIZE = 5;

    // Time (ms) before REsending all the non-acked packets
    public static final int TIMER = 30;

    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);
	    System.out.println("Please enter IP address");
            String ip = scanner.nextLine();
            System.out.println("Please enter port number");
            String port = scanner.nextLine();
	    System.out.println("Enter bit error rate");
  	    String err = scanner.nextLine();

            System.out.println("Your available functions are:\nlist\nget\nexit");
            System.out.println("Please enter your input: ");
            String command = scanner.nextLine();

            if (command.equals("list")) {
                File directoryPath = new File("/home/grads/sudhabat/CN");
                String contents[] = directoryPath.list();
                System.out.println("List of files and directories in the specified directory:");
                for (int i = 0; i < contents.length; i++) {
                    System.out.println(contents[i]);
                }

                System.out.println("Please enter your input: ");
                command = scanner.nextLine();

            }
            if (command == "exit") {
                System.exit(0);
                System.out.println("This is Unreachable");

            } else if (command.contains("get")) {
               
                try {

                    String fileName = command.replace("get","");

                    sendFile(fileName.trim(),ip,port,err);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }



    }

    public static void sendFile(String filename,String ip,String port,String err) throws Exception {
	System.out.println("fileName--"+filename+"IP--"+ip+"Port--"+port);

	PROBABILITY = Double.parseDouble(err);
        // Sequence number of the last packet sent (rcvbase)
        int lastSent = 0;

        // Sequence number of the last acked packet
        int waitingForAck = 0;

        // Data to be sent (you can, and should, use your own Data-> byte[] function here)
        
	String data = "";
	try {

            File myObj = new File("/home/grads/sudhabat/CC/"+filename);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();


        } catch (FileNotFoundException ex) {
            System.out.println("An error occurred.");
            ex.printStackTrace();
        }




        byte[] fileBytes = data.getBytes();

        System.out.println("Data size: " + fileBytes.length + " bytes");

        // Last packet sequence number
        int lastSeq = (int) Math.ceil((double) fileBytes.length / MSS);

        System.out.println("Number of packets to send: " + lastSeq);

        DatagramSocket toReceiver = new DatagramSocket();

        // Receiver address
        InetAddress receiverAddress = InetAddress.getByName("localhost");

        // List of all the packets sent
        ArrayList < RDTPacket > sent = new ArrayList < RDTPacket > ();

        while (true) {

            // Sending loop
            while (lastSent - waitingForAck < WINDOW_SIZE && lastSent < lastSeq) {

                // Array to store part of the bytes to send
                byte[] filePacketBytes = new byte[MSS];

                // Copy segment of data bytes to array
                filePacketBytes = Arrays.copyOfRange(fileBytes, lastSent * MSS, lastSent * MSS + MSS);

                // Create RDTPacket object
                RDTPacket rdtPacketObject = new RDTPacket(lastSent, filePacketBytes, (lastSent == lastSeq - 1) ? true : false);

                // Serialize the RDTPacket object
                byte[] sendData = Serializer.toBytes(rdtPacketObject);

                // Create the packet
                DatagramPacket packet = new DatagramPacket(sendData, sendData.length, receiverAddress, 9876);
		Thread.sleep(1000);
                System.out.println("Sending packet with sequence number " + lastSent + " and size " + sendData.length + " bytes");

                // Add packet to the sent list
                sent.add(rdtPacketObject);

                // Send with some probability of loss
                if (Math.random() > PROBABILITY) {
                    toReceiver.send(packet);
                } else {
                    System.out.println("[X] Lost packet with sequence number " + lastSent);
                }

                // Increase the last sent
                lastSent++;

            } // End of sending while

            // Byte array for the ACK sent by the receiver
            byte[] ackBytes = new byte[1024];

            // Creating packet for the ACK
            DatagramPacket ack = new DatagramPacket(ackBytes, ackBytes.length);

            try {
                // If an ACK was not received in the time specified (continues on the catch clausule)
                toReceiver.setSoTimeout(TIMER);

                // Receive the packet
                toReceiver.receive(ack);

                // Unserialize the RDTAck object
                RDTAck ackObject = (RDTAck) Serializer.toObject(ack.getData());
		
                System.out.println("Received ACK for " + ackObject.getPacket());
		Thread.sleep(4000);

                // If this ack is for the last packet, stop the sender (Note: gbn has a cumulative acking)
                if (ackObject.getPacket() == lastSeq) {
                    break;
                }

                waitingForAck = Math.max(waitingForAck, ackObject.getPacket());

            } catch (SocketTimeoutException e) {
                // then send all the sent but non-acked packets

                for (int i = waitingForAck; i < lastSent; i++) {

                    // Serialize the RDTPacket object
                    byte[] sendData = Serializer.toBytes(sent.get(i));

                    // Create the packet
                    DatagramPacket packet = new DatagramPacket(sendData, sendData.length, receiverAddress, 9876);

                    // Send with some probability
                    if (Math.random() > PROBABILITY) {
			System.out.println(PROBABILITY);
                        toReceiver.send(packet);
                    } else {
                        System.out.println("[X] Lost packet with sequence number " + sent.get(i).getSeq());
                    }

                    System.out.println("REsending packet with sequence number " + sent.get(i).getSeq() + " and size " + sendData.length + " bytes");
                }
            }


        }

        System.out.println("Finished transmission");

    }

}
